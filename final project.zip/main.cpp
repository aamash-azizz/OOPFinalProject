#include <iostream>
#include "project.h"
using namespace std;

int main() {
    cout << "Welcome to Legend of Valour!\n";
    Kingdom kingdom("PAKISTAN", "MUNEEB");

    while (true) {
        kingdom.displayStatus();
        kingdom.applyCorruption();
        cout << "\nChoose an action:\n";
        cout << "1. Collect Taxes\n";
        cout << "2. Train Army in Barracks\n";
        cout << "3. Elect King\n";
        cout << "4. Elect Commander\n";
        cout << "5. Handle Random Event\n";
        cout << "6. Manage Bank (Loan/Repay)\n";
        cout << "7. Audit Finances\n";
        cout << "8. Manage Resources\n";
        cout << "9. Handle Trade\n";
        cout << "10. Save Game\n";
        cout << "11. Load Game\n";
        cout << "12. Exit\n";
        cout << "Enter choice (1-12): ";

        int choice;
        cin >> choice;

        try {
            if (cin.fail()) {
                cin.clear();
                cin.ignore(10000, '\n');
                throw string("Invalid input! Please enter a number.");
            }

            switch (choice) {
            case 1:
                kingdom.collectTaxes();
                break;
            case 2:
                kingdom.trainInBarracks();
                break;
            case 3:
                kingdom.electKing();
                break;
            case 4:
                kingdom.electCommander();
                break;
            case 5:
                kingdom.handleRandomEvent();
                break;
            case 6:
                kingdom.manageBank();
                break;
            case 7:
                kingdom.auditFinances();
                break;
            case 8:
                kingdom.manageResources();
                break;
            case 9:
                kingdom.handleTrade();
                break;
            case 10:
                kingdom.saveGame();
                break;
            case 11:
                kingdom.loadGame();
                break;
            case 12:
                cout << "Exiting game. Goodbye!\n";
                return 0;
            default:
                throw string("Invalid choice! Choose between 1 and 12.");
            }
        }
        catch (string& e) {
            cout << "Error: " << e << "\n";
        }
    }

    return 0;
}