#pragma once
#include <string>
#include <memory>

using namespace std;

// Forward declarations to avoid circular dependencies
class Leader;
class King;
class Commander;
class MerchantGuildLeader;
class Candidate;
class SocialClass;
class Market;
class Kingdom;

// Base class for leaders (supports inheritance and polymorphism)
class Leader {
protected:
    string name;
    int leadershipSkill; // Affects taxes, diplomacy, military
public:
    Leader(string n, int skill);
    virtual void makeDecision() = 0; // Pure virtual function for polymorphism
    virtual ~Leader();
    string getName() const;
    int getLeadershipSkill() const;
};

// Derived class for King
class King : public Leader {
public:
    King(string n, int skill);
    void makeDecision() override;
};

// Derived class for Commander
class Commander : public Leader {
public:
    Commander(string n, int skill);
    void makeDecision() override;
};

// Derived class for Merchant Guild Leader
class MerchantGuildLeader : public Leader {
public:
    MerchantGuildLeader(string n, int skill);
    void makeDecision() override;
};

// Template class for resources
template <typename T>
class Resource {
private:
    T quantity;
public:
    Resource(T q = 0) : quantity(q) {}
    void setQuantity(T q) {
        if (q < 0) throw string("Quantity cannot be negative!");
        quantity = q;
    }
    T getQuantity() const { return quantity; }
    void add(T q) {
        if (q < 0) throw string("Cannot add negative quantity!");
        quantity += q;
    }
    void remove(T q) {
        if (q < 0 || q > quantity) throw string("Invalid removal quantity!");
        quantity -= q;
    }
};

// Class for social classes (peasants, merchants, nobility, military)
class SocialClass {
public:
    string name;
    int satisfaction; // 0-100, affects stability/morale
    int populationShare; // Portion of total population
    SocialClass(string n, int s, int p);
    void adjustSatisfaction(int delta);
};

// Class for candidates (used in king/commander elections)
class Candidate {
public:
    string name;
    int skill;
    Candidate(string n, int s);
};

// Class for market (handles supply/demand)
class Market {
private:
    int foodPrice; // Dynamic price based on supply/demand
    int supplyLevel; // 0-100, affects price
    int demandLevel; // 0-100, affects price
public:
    Market();
    void updateMarket(); // Randomly adjust supply/demand
    int getFoodPrice() const;
};

// Main Kingdom class 
class Kingdom {
private:
    string name;
    unique_ptr<King> king; // Smart pointer for king
    unique_ptr<Commander> commander; // Smart pointer for commander
    unique_ptr<MerchantGuildLeader> merchantLeader; // For trade
    Resource<int> population;
    Resource<int> gold;
    Resource<int> army;
    Resource<int> food;
    Resource<int> weapons;
    Resource<int> wood;
    Resource<int> stone;
    Resource<int> iron;
    int stability; // Affects revolt chance
    int loan; // Tracks borrowed gold
    int corruptionLevel; // Affects gold loss
    int morale; // Army morale
    bool tradeSanction; // Simulates trade restrictions
    int tradeRouteSecurity; // 0-100, affects trade success
    int inflationRate; // Affects gold value
    SocialClass socialClasses[4]; // Peasants, merchants, nobility, military
    Candidate kingCandidates[3]; // Fixed array for king election
    Candidate commanderCandidates[3]; // Fixed array for commander election
    Market market; // Manages market 
    static const int MAX_CANDIDATES = 3;
    static const int MAX_CLASSES = 4;

public:
    Kingdom(string n, string kingName);
    void displayStatus();
    void collectTaxes();
    void trainInBarracks();
    void electKing();
    void electCommander();
    void handleRandomEvent();
    void checkStability();
    void manageBank();
    void auditFinances();
    void manageResources();
    void handleTrade();
    void applyCorruption();
    void saveGame();
    void loadGame();
};