#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <thread>
#include <chrono>
#include "project.h"

using namespace std;

// Leader class 
Leader::Leader(string n, int skill) : name(n), leadershipSkill(skill) {}
Leader::~Leader() {}
string Leader::getName() const { return name; }
int Leader::getLeadershipSkill() const { return leadershipSkill; }

// King class 
King::King(string n, int skill) : Leader(n, skill) {}
void King::makeDecision() {
    cout << name << " issues a royal decree with skill " << leadershipSkill << "!\n";
}

// Commander class 
Commander::Commander(string n, int skill) : Leader(n, skill) {}
void Commander::makeDecision() {
    cout << name << " leads the army with skill " << leadershipSkill << "!\n";
}

// MerchantGuildLeader 
MerchantGuildLeader::MerchantGuildLeader(string n, int skill) : Leader(n, skill) {}
void MerchantGuildLeader::makeDecision() {
    cout << name << " negotiates trade with skill " << leadershipSkill << "!\n";
}
//social class
SocialClass::SocialClass(string n, int s, int p) : name(n), satisfaction(s), populationShare(p) {}
void SocialClass::adjustSatisfaction(int delta) {
    satisfaction = max(0, min(100, satisfaction + delta));
}

// Candidate class 
Candidate::Candidate(string n, int s) : name(n), skill(s) {}

// Market class 
Market::Market() : foodPrice(50), supplyLevel(50), demandLevel(50) {}
void Market::updateMarket() {
    srand(time(0));
    supplyLevel += (rand() % 21) - 10; // -10 to +10
    demandLevel += (rand() % 21) - 10;//-10 to +10
    supplyLevel = max(0, min(100, supplyLevel));
    demandLevel = max(0, min(100, demandLevel));
    foodPrice = 50 + (demandLevel - supplyLevel); // Price fluctuates
}
int Market::getFoodPrice() const { return foodPrice; }

// Kingdom class 
Kingdom::Kingdom(string n, string kingName)
    : name(n), king(new King(kingName, 70)), commander(new Commander("Gawain", 60)),
    merchantLeader(new MerchantGuildLeader("Merchant Guild", 60)),
    population(1000), gold(500), army(100), food(500), weapons(200),
    wood(300), stone(300), iron(200), stability(80), loan(0),
    corruptionLevel(10), morale(80), tradeSanction(false),
    tradeRouteSecurity(80), inflationRate(5),
    socialClasses{ SocialClass("Peasants", 70, 600), SocialClass("Merchants", 60, 200),
                  SocialClass("Nobility", 80, 100), SocialClass("Military", 70, 100) },
    kingCandidates{ Candidate("AAMASH", 50), Candidate("MUNEEB", 70), Candidate("AHMAD", 30) },
    commanderCandidates{ Candidate("Gawain", 60), Candidate("Percival", 80), Candidate("Bors", 40) },
    market() {
    cout << "Kingdom " << name << " established under King " << king->getName() << "!\n";
}

void Kingdom::displayStatus() {
    cout << "\n=== Kingdom Status ===\n";
    cout << "Name: " << name << "\n";
    cout << "King: " << king->getName() << " (Skill: " << king->getLeadershipSkill() << ")\n";
    cout << "Commander: " << commander->getName() << " (Skill: " << commander->getLeadershipSkill() << ")\n";
    cout << "Merchant Leader: " << merchantLeader->getName() << "\n";
    cout << "Population: " << population.getQuantity() << "\n";
    cout << "Social Classes:\n";
    for (int i = 0; i < MAX_CLASSES; i++) {
        cout << "  " << socialClasses[i].name << ": " << socialClasses[i].populationShare
            << " (Satisfaction: " << socialClasses[i].satisfaction << "%)\n";
    }
    cout << "Gold: " << gold.getQuantity() << "\n";
    cout << "Army: " << army.getQuantity() << "\n";
    cout << "Food: " << food.getQuantity() << "\n";
    cout << "Weapons: " << weapons.getQuantity() << "\n";
    cout << "Wood: " << wood.getQuantity() << "\n";
    cout << "Stone: " << stone.getQuantity() << "\n";
    cout << "Iron: " << iron.getQuantity() << "\n";
    cout << "Stability: " << stability << "%\n";
    cout << "Loan: " << loan << " gold\n";
    cout << "Corruption Level: " << corruptionLevel << "%\n";
    cout << "Army Morale: " << morale << "%\n";
    cout << "Trade Sanction: " << (tradeSanction ? "Yes" : "No") << "\n";
    cout << "Trade Route Security: " << tradeRouteSecurity << "%\n";
    cout << "Inflation Rate: " << inflationRate << "%\n";
    cout << "Market Food Price: " << market.getFoodPrice() << " gold\n";
}

void Kingdom::collectTaxes() {
    try {
        int taxRate = king->getLeadershipSkill() / 10;
        if (taxRate > 5) inflationRate += 2; // High taxes cause inflation
        int tax = (population.getQuantity() * taxRate) / 100;
        gold.add(tax);
        stability -= taxRate;
        // Social class 
        socialClasses[0].adjustSatisfaction(-taxRate); // Peasants dislike taxes
        socialClasses[2].adjustSatisfaction(taxRate > 5 ? -10 : 5); // Nobility hate high taxes
        socialClasses[3].adjustSatisfaction(taxRate < 3 ? -5 : 5); // Military want moderate taxes
        if (socialClasses[2].satisfaction < 30) {
            stability -= 10; // Nobility riot
            cout << "Nobility riots due to high taxes!\n";
        }
        cout << "Collected " << tax << " gold in taxes.\n";
        checkStability();
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::trainInBarracks() {
    try {
        if (gold.getQuantity() < 50) throw string("Not enough gold to train army!");
        if (population.getQuantity() < 100) throw string("Not enough population to recruit!");
        if (weapons.getQuantity() < 50) throw string("Not enough weapons to equip army!");
        if (wood.getQuantity() < 50) throw string("Not enough wood for barracks!");
        cout << "Training army in barracks... (5 seconds)\n";
        this_thread::sleep_for(chrono::seconds(5));
        army.add(50);
        gold.remove(50);
        population.remove(50);
        weapons.remove(50);
        wood.remove(50);
        morale = min(100, morale + 5);
        socialClasses[3].adjustSatisfaction(10); // Military likes training
        commander->makeDecision();
        cout << "Trained 50 soldiers!\n";
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::electKing() {
    try {
        cout << "Choose a new king:\n";
        for (int i = 0; i < MAX_CANDIDATES; i++) {
            cout << i + 1 << ". " << kingCandidates[i].name << " (Skill: " << kingCandidates[i].skill << ")\n";
        }
        cout << "Options:\n1. Vote\n2. Bribe Voters (50 gold)\n3. Blackmail Opponent\nEnter choice (1-3): ";
        int option;
        cin >> option;
        if (cin.fail() || option < 1 || option > 3) {
            cin.clear();
            cin.ignore(10000, '\n');
            throw string("Invalid election option!");
        }
        int choice;
        if (option == 1) {
            cout << "Enter candidate (1-3): ";
            cin >> choice;
        }
        else if (option == 2) {
            if (gold.getQuantity() < 50) throw string("Not enough gold to bribe!");
            gold.remove(50);
            cout << "Bribed voters! Mordred gains support.\n";
            kingCandidates[2].skill += 20; // Boost Mordred temporarily
            cout << "Enter candidate (1-3): ";
            cin >> choice;
            kingCandidates[2].skill -= 20; // Reset skill
        }
        else {
            stability -= 15;
            cout << "Blackmailed opponent! Lancelot withdraws.\n";
            choice = 3; // Force Mordred
        }
        if (cin.fail() || choice < 1 || choice > MAX_CANDIDATES) {
            cin.clear();
            cin.ignore(10000, '\n');
            throw string("Invalid candidate choice!");
        }
        king = unique_ptr<King>(new King(kingCandidates[choice - 1].name, kingCandidates[choice - 1].skill));
        stability -= 10;
        cout << "New king elected: " << king->getName() << "!\n";
        checkStability();
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::electCommander() {
    try {
        cout << "Choose a new commander:\n";
        for (int i = 0; i < MAX_CANDIDATES; i++) {
            cout << i + 1 << ". " << commanderCandidates[i].name << " (Skill: " << commanderCandidates[i].skill << ")\n";
        }
        cout << "Enter choice (1-3): ";
        int choice;
        cin >> choice;
        if (cin.fail() || choice < 1 || choice > MAX_CANDIDATES) {
            cin.clear();
            cin.ignore(10000, '\n');
            throw string("Invalid candidate choice!");
        }
        commander = unique_ptr<Commander>(new Commander(commanderCandidates[choice - 1].name, commanderCandidates[choice - 1].skill));
        stability -= 5;
        morale = min(100, morale + 10);
        socialClasses[3].adjustSatisfaction(10); // Military likes new commander
        cout << "New commander elected: " << commander->getName() << "!\n";
        checkStability();
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::handleRandomEvent() {
    srand(time(0));
    int event = rand() % 10; // Expanded events
    try {
        switch (event) {
        case 0:
            cout << "Plague strikes! Population and stability decrease.\n";
            population.remove(200);
            stability -= 10;
            socialClasses[0].adjustSatisfaction(-10); // Peasants suffer
            break;
        case 1:
            cout << "Drought hits! Food production halts.\n";
            food.remove(100);
            stability -= 5;
            socialClasses[0].adjustSatisfaction(-5);
            break;
        case 2:
            cout << "Enemy raid! Lose army, gold, and weapons.\n";
            army.remove(50);
            gold.remove(50);
            weapons.remove(50);
            morale -= 10;
            stability -= 10;
            socialClasses[3].adjustSatisfaction(-10);
            break;
        case 3:
            cout << "Bank heist! Lose gold due to fraud.\n";
            gold.remove(100);
            corruptionLevel += 5;
            break;
        case 4:
            cout << "Trade sanction imposed! Cannot trade this turn.\n";
            tradeSanction = true;
            socialClasses[1].adjustSatisfaction(-10); // Merchants unhappy
            break;
        case 5:
            cout << "Market crash! Economy suffers massive loss.\n";
            gold.remove(200);
            stability -= 15;
            inflationRate += 5;
            break;
        case 6:
            cout << "King assassinated! Must elect new king.\n";
            stability -= 20;
            electKing();
            break;
        case 7:
            cout << "Smuggler caught! Pay 50 gold fine or lose stability.\n";
            cout << "1. Pay fine\n2. Ignore\nEnter choice (1-2): ";
            int choice;
            cin >> choice;
            if (cin.fail() || choice < 1 || choice > 2) {
                cin.clear();
                cin.ignore(10000, '\n');
                throw string("Invalid smuggler choice!");
            }
            if (choice == 1) {
                if (gold.getQuantity() < 50) throw string("Not enough gold to pay fine!");
                gold.remove(50);
                cout << "Fine paid.\n";
            }
            else {
                stability -= 10;
                cout << "Ignored smuggler, stability decreased.\n";
            }
            break;
        case 8:
            cout << "Bandit attack on trade routes! Security decreased.\n";
            tradeRouteSecurity -= 20;
            tradeRouteSecurity = max(0, tradeRouteSecurity);
            socialClasses[1].adjustSatisfaction(-5);
            break;
        case 9:
            cout << "Harsh winter! Food production reduced.\n";
            food.remove(150);
            stability -= 10;
            socialClasses[0].adjustSatisfaction(-10);
            break;
        }
        checkStability();
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::checkStability() {
    if (stability < 20) {
        cout << "Revolt! Population, army, and stability decrease!\n";
        population.remove(100);
        army.remove(50);
        stability = 50;
        morale -= 10;
        for (int i = 0; i < MAX_CLASSES; i++) {
            socialClasses[i].adjustSatisfaction(-10);
        }
    }
    if (morale < 20) {
        cout << "Army deserts due to low morale! Lose soldiers.\n";
        army.remove(50);
        morale = 50;
        socialClasses[3].adjustSatisfaction(-10);
    }
}

void Kingdom::manageBank() {
    try {
        cout << "Bank Options:\n1. Take Loan (100 gold, 10% interest)\n2. Repay Loan\nEnter choice (1-2): ";
        int choice;
        cin >> choice;
        if (cin.fail() || choice < 1 || choice > 2) {
            cin.clear();
            cin.ignore(10000, '\n');
            throw string("Invalid bank choice!");
        }
        if (choice == 1) {
            if (loan > 0) throw string("You already have a loan!");
            gold.add(100);
            loan = 110;
            inflationRate += 3; // Loans increase inflation
            cout << "Took 100 gold loan. Must repay " << loan << " gold.\n";
        }
        else {
            if (loan == 0) throw string("No loan to repay!");
            if (gold.getQuantity() < loan) throw string("Not enough gold to repay loan!");
            gold.remove(loan);
            loan = 0;
            cout << "Loan repaid!\n";
        }
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::auditFinances() {
    try {
        if (gold.getQuantity() < 50) throw string("Not enough gold to audit!");
        cout << "Auditing finances... (3 seconds)\n";
        this_thread::sleep_for(chrono::seconds(3));
        gold.remove(50);
        corruptionLevel = max(0, corruptionLevel - 5);
        cout << "Audit complete! Corruption reduced to " << corruptionLevel << "%.\n";
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::manageResources() {
    try {
        cout << "Resource Options:\n 1. Produce Food (50 gold)\n2. Produce Weapons (50 gold, 50 iron, 3 seconds)\n"
            << "3. Produce Wood (50 gold)\n 4. Produce Stone (50 gold)\n5. Produce Iron (50 gold)\n"
            << "Enter choice (1-5): ";
        int choice;
        cin >> choice;
        if (cin.fail() || choice < 1 || choice > 5) {
            cin.clear();
            cin.ignore(10000, '\n');
            throw string("Invalid resource choice!");
        }
        if (gold.getQuantity() < 50) throw string("Not enough gold to produce!");
        gold.remove(50);
        if (choice == 1) {
            int foodGain = 100 * (100 - inflationRate) / 100; // Inflation reduces gain
            food.add(foodGain);
            cout << "Produced " << foodGain << " food!\n";
        }
        else if (choice == 2) {
            if (iron.getQuantity() < 50) throw string("Not enough iron for weapons!");
            if (socialClasses[1].populationShare < 50) throw string("Not enough merchants for blacksmiths!");
            cout << "Blacksmiths forging weapons... (3 seconds)\n";
            this_thread::sleep_for(chrono::seconds(3));
            iron.remove(50);
            weapons.add(100);
            socialClasses[1].adjustSatisfaction(5); // Merchants benefit
            cout << "Produced 100 weapons!\n";
        }
        else if (choice == 3) {
            wood.add(100);
            cout << "Produced 100 wood!\n";
        }
        else if (choice == 4) {
            stone.add(100);
            cout << "Produced 100 stone!\n";
        }
        else {
            iron.add(100);
            cout << "Produced 100 iron!\n";
        }
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::handleTrade() {
    try {
        market.updateMarket();
        if (tradeSanction) {
            cout << "Cannot trade due to sanctions!\n";
            tradeSanction = false;
            socialClasses[1].adjustSatisfaction(-5);
            return;
        }
        if (tradeRouteSecurity < 30) {
            cout << "Trade routes too dangerous!\n";
            socialClasses[1].adjustSatisfaction(-5);
            return;
        }
        int foodOffer = 50 + (rand() % 51);
        int goldCost = market.getFoodPrice() * foodOffer / 50; // Market-based price
        cout << "Trade Offer from Neighboring Kingdom:\n";
        cout << "Offer: " << foodOffer << " food for " << goldCost << " gold.\n";
        cout << "Enter a negotiation message (or 'none'): ";
        string message;
        cin.ignore();
        getline(cin, message);
        cout << "Sent message: " << message << "\n";
        cout << "1. Accept\n2. Reject\nEnter choice (1-2): ";
        int choice;
        cin >> choice;
        if (cin.fail() || choice < 1 || choice > 2) {
            cin.clear();
            cin.ignore(10000, '\n');
            throw string("Invalid trade choice!");
        }
        if (choice == 1) {
            if (gold.getQuantity() < goldCost) throw string("Not enough gold to trade!");
            gold.remove(goldCost);
            food.add(foodOffer);
            cout << "Trade accepted! Gained " << foodOffer << " food.\n";
            merchantLeader->makeDecision();
            socialClasses[1].adjustSatisfaction(10);
        }
        else {
            cout << "Trade rejected. Merchants are unhappy.\n";
            stability -= 5;
            socialClasses[1].adjustSatisfaction(-10);
            if (socialClasses[1].satisfaction < 30) {
                cout << "Merchant guild boycotts trade!\n";
                tradeSanction = true;
            }
        }
        checkStability();
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::applyCorruption() {
    try {
        int loss = (gold.getQuantity() * corruptionLevel) / 100;
        gold.remove(loss);
        cout << "Corruption causes " << loss << " gold loss!\n";
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::saveGame() {
    try {
        ofstream file("score.txt");
        if (!file.is_open()) throw string("Cannot open file for saving!");
        file << name << "\n";
        file << king->getName() << "\n";
        file << king->getLeadershipSkill() << "\n";
        file << commander->getName() << "\n";
        file << commander->getLeadershipSkill() << "\n";
        for (int i = 0; i < MAX_CLASSES; i++) {
            file << socialClasses[i].name << " " << socialClasses[i].satisfaction << " "
                << socialClasses[i].populationShare << "\n";
        }
        file << population.getQuantity() << "\n";
        file << gold.getQuantity() << "\n";
        file << army.getQuantity() << "\n";
        file << food.getQuantity() << "\n";
        file << weapons.getQuantity() << "\n";
        file << wood.getQuantity() << "\n";
        file << stone.getQuantity() << "\n";
        file << iron.getQuantity() << "\n";
        file << stability << "\n";
        file << loan << "\n";
        file << corruptionLevel << "\n";
        file << morale << "\n";
        file << (tradeSanction ? 1 : 0) << "\n";
        file << tradeRouteSecurity << "\n";
        file << inflationRate << "\n";
        file.close();
        cout << "Game saved successfully!\n";
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}

void Kingdom::loadGame() {
    try {
        ifstream file("score.txt");
        if (!file.is_open()) throw string("Cannot open file for loading!");
        string kingName, commanderName;
        int kingSkill, commanderSkill, pop, gld, arm, fd, wpn, wd, st, ir, stab, ln, corr, mor;
        bool sanc;
        int security, inflation;
        getline(file, name);
        getline(file, kingName);
        file >> kingSkill;
        file.ignore();
        getline(file, commanderName);
        file >> commanderSkill;
        file.ignore();
        for (int i = 0; i < MAX_CLASSES; i++) {
            string className;
            int sat, share;
            file >> className >> sat >> share;
            socialClasses[i] = SocialClass(className, sat, share);
        }
        file >> pop >> gld >> arm >> fd >> wpn >> wd >> st >> ir >> stab >> ln >> corr >> mor >> sanc >> security >> inflation;
        file.close();
        king = unique_ptr<King>(new King(kingName, kingSkill));
        commander = unique_ptr<Commander>(new Commander(commanderName, commanderSkill));
        population.setQuantity(pop);
        gold.setQuantity(gld);
        army.setQuantity(arm);
        food.setQuantity(fd);
        weapons.setQuantity(wpn);
        wood.setQuantity(wd);
        stone.setQuantity(st);
        iron.setQuantity(ir);
        stability = stab;
        loan = ln;
        corruptionLevel = corr;
        morale = mor;
        tradeSanction = sanc;
        tradeRouteSecurity = security;
        inflationRate = inflation;
        cout << "Game loaded successfully!\n";
    }
    catch (string& e) {
        cout << "Error: " << e << "\n";
    }
}